from qpanel import app

app.main()
