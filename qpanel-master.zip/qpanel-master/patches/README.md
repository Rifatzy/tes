Here you can find some patch utils for add more powerfull to QPanel

Some was added in principal code of projects. If you actual version is not
patched so you can apply this patches.

